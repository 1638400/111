#ifndef PTRHOOK_PERSP_H
#define PTRHOOK_PERSP_H

#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <sys/mman.h>
#include <android/log.h>
//交流群 720746553 树某
// ===================== 你的游戏偏移配置 =====================
#define TARGET_SO_NAME        "libunity.so"
// 1. TBZ透视指令XA段偏移（全程不会修改此处）
#define TBZ_INSN_OFFSET       0x8E4C49C
// 2. 【需要你IDA逆向填入】存储TBZ所属函数的全局RW数据段指针偏移
#define GLOBAL_FUNC_PTR_OFF   0x00000000
// 3. TBZ所属原生函数地址偏移
#define ORIG_FUNC_OFFSET      0x00000000
#define MODULE_WAIT_US        10000
#define STACK_ALIGN_SIZE      0x40
#define TMP_JUMP_PAGE_SIZE    4096
// 原始TBZ机器码 TBZ X0,#0x0,[PC,#0x10]
#define RAW_TBZ_MACHINE       0xB8000068
// ==========================================================

#define LOG_TAG "PtrHook无痕透视"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// 全局状态
static uintptr_t    g_so_base        = 0;
static uintptr_t    g_global_ptr_var  = 0;    // 数据段全局函数指针变量地址
static uintptr_t    g_origin_func     = 0;    // 游戏原生TBZ逻辑函数地址
static uintptr_t    g_jump_plat_addr  = 0;    // 匿名mmap跳板内存地址
static uint64_t     g_backup_origin_ptr= 0;   // 备份原始指针值
static bool         g_init            = false;

// 等待SO加载，获取XA段基址
static bool get_so_base(const char* so_name, uintptr_t* out_base)
{
    if (!out_base || !so_name) return false;
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) return false;

    char line[1024] = {0};
    while (fgets(line, sizeof(line), fp))
    {
        // 只匹配r-xp代码段基址
        if (strstr(line, so_name) && strstr(line, "r-xp"))
        {
            uintptr_t base = 0;
            if (sscanf(line, "%lx-", &base) == 1)
            {
                *out_base = base;
                fclose(fp);
                return true;
            }
        }
    }
    fclose(fp);
    return false;
}

// 分配私有匿名可执行跳板内存（不在libunity.so内，XA完全无修改）
static uintptr_t alloc_jump_plat(size_t size)
{
    void* plat = mmap(
        nullptr,
        size,
        PROT_READ | PROT_WRITE,
        MAP_PRIVATE | MAP_ANONYMOUS,
        -1,
        0
    );
    if (plat == MAP_FAILED)
    {
        LOGE("跳板内存分配失败");
        return 0;
    }
    // 写入完成后修改为只读可执行
    mprotect(plat, size, PROT_READ | PROT_EXEC);
    return (uintptr_t)plat;
}

// 释放跳板内存
static void free_jump_plat(uintptr_t addr, size_t size)
{
    if (addr == 0) return;
    munmap((void*)addr, size);
}

// 填充跳板ARM64汇编逻辑（等效TBZ NOP，强制屏蔽遮挡分支实现透视）
static void fill_persp_jump_asm(uintptr_t plat_addr, uintptr_t orig_func)
{
    uint8_t* asm_buf = (uint8_t*)plat_addr;
    int idx = 0;

    // 1. 栈保存现场，防止寄存器污染游戏逻辑
    // stp x29, x30, [sp, #-0x40]!
    uint32_t stp_stack = 0xA9BF7BFD;
    memcpy(asm_buf + idx, &stp_stack, 4); idx += 4;

    // 核心透视逻辑：修改X0=1，强制TBZ分支不跳转，等效把TBZ改成NOP
    // mov x0, #1
    uint32_t mov_x0_1 = 0xD2800020;
    memcpy(asm_buf + idx, &mov_x0_1, 4); idx += 4;

    // 空指令对齐
    uint32_t nop_ins = 0xD503201F;
    memcpy(asm_buf + idx, &nop_ins, 4); idx += 4;
    memcpy(asm_buf + idx, &nop_ins, 4); idx += 4;

    // 跳转回游戏原始TBZ逻辑函数
    // ldr x16, =orig_func; br x16
    uint64_t target_br = orig_func;
    memcpy(asm_buf + idx, &target_br, 8); idx += 8;
    uint32_t br_x16 = 0xD61F0200;
    memcpy(asm_buf + idx, &br_x16, 4); idx += 4;

    // 恢复栈现场返回
    // ldp x29, x30, [sp], #0x40; ret
    uint32_t ldp_stack = 0xA8C17BFD;
    memcpy(asm_buf + idx, &ldp_stack, 4); idx += 4;
    uint32_t ret_ins = 0xD65F03C0;
    memcpy(asm_buf + idx, &ret_ins, 4); idx += 4;
}

// 启动PtrHook指针劫持（无痕透视主入口）
static int persp_ptr_hook_start(void)
{
    if (g_init)
    {
        LOGI("无痕透视已加载，禁止重复初始化");
        return -1;
    }

    // 等待libunity.so加载完成
    LOGI("等待 libunity.so XA代码段加载...");
    while (!get_so_base(TARGET_SO_NAME, &g_so_base))
    {
        usleep(MODULE_WAIT_US);
    }
    LOGI("libunity.so XA基址: 0x%lx", g_so_base);

    // 校验XA段TBZ原始指令，确认全程未被修改
    uintptr_t tbz_xa_addr = g_so_base + TBZ_INSN_OFFSET;
    uint32_t check_tbz_ins = *(volatile uint32_t*)tbz_xa_addr;
    if (check_tbz_ins != RAW_TBZ_MACHINE)
    {
        LOGE("❌ XA段TBZ指令已被篡改，禁止启动");
        return -2;
    }
    LOGI("✅ XA段TBZ原始指令完整，无任何字节修改");

    // 计算全局函数指针变量地址（RW数据段，可读写，不碰XA代码段）
    g_global_ptr_var = g_so_base + GLOBAL_FUNC_PTR_OFF;
    // 计算游戏原生TBZ逻辑函数地址
    g_origin_func = g_so_base + ORIG_FUNC_OFFSET;
    LOGI("全局指针变量(数据段):0x%lx | 原生TBZ函数:0x%lx", g_global_ptr_var, g_origin_func);

    // 备份原始指针值，卸载时还原
    g_backup_origin_ptr = *(volatile uint64_t*)g_global_ptr_var;
    LOGI("备份原始函数指针:0x%lx", g_backup_origin_ptr);

    // 分配独立匿名跳板内存
    g_jump_plat_addr = alloc_jump_plat(TMP_JUMP_PAGE_SIZE);
    if (g_jump_plat_addr == 0)
    {
        LOGE("跳板内存分配失败");
        return -3;
    }

    // 填充透视自定义汇编逻辑
    fill_persp_jump_asm(g_jump_plat_addr, g_origin_func);
    LOGI("透视跳板汇编写入完成，跳板地址:0x%lx", g_jump_plat_addr);

    // 【核心劫持】修改数据段全局指针，指向我们的跳板，XA段零改动
    *(volatile uint64_t*)g_global_ptr_var = g_jump_plat_addr;

    g_init = true;
    LOGI("✅ PtrHook无痕透视加载完成，XA代码段无任何篡改");
    return 0;
}

// 完整卸载，一键还原所有内存修改，无残留
static void persp_ptr_hook_stop(void)
{
    if (!g_init) return;
    LOGI("开始卸载无痕透视PtrHook...");

    // 1. 还原数据段全局指针为游戏原始值
    *(volatile uint64_t*)g_global_ptr_var = g_backup_origin_ptr;
    LOGI("已恢复原版全局函数指针");

    // 2. 释放匿名跳板内存
    if (g_jump_plat_addr != 0)
    {
        free_jump_plat(g_jump_plat_addr, TMP_JUMP_PAGE_SIZE);
        g_jump_plat_addr = 0;
        LOGI("跳板内存已释放");
    }

    // 清空全局状态
    g_backup_origin_ptr = 0;
    g_global_ptr_var = 0;
    g_origin_func = 0;
    g_so_base = 0;
    g_init = false;

    LOGI("🔴 无痕透视完全释放，内存无任何修改痕迹");
}

#endif

