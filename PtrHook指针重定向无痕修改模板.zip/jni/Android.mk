LOCAL_PATH := $(call my-dir)

# 构建主模块
include $(CLEAR_VARS)
LOCAL_MODULE := bypass_crc
LOCAL_SRC_FILES := main.cpp
LOCAL_LDLIBS := -llog
LOCAL_CPPFLAGS += -std=c++11 -fvisibility=hidden
include $(BUILD_SHARED_LIBRARY)
