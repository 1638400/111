#include "PtrHook_Persp.h"
#include <unistd.h>
#include <android/log.h>

#define DELAY_MS 2000
#define LOG_TAG "透视自动加载器"

// SO注入游戏后自动执行，调用透视启动函数
__attribute__((constructor)) void mod_auto_start()
{
    // 延迟等待libunity.so加载完毕
    usleep(DELAY_MS * 1000);
    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "开始调用无痕透视启动函数 persp_ptr_hook_start()");
    
    int ret = persp_ptr_hook_start();
    if(ret == 0)
    {
        __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "persp_ptr_hook_start 调用成功，透视开启");
    }
    else
    {
        __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "persp_ptr_hook_start 调用失败，错误码:%d", ret);
    }
}

// 游戏进程退出自动调用卸载函数，还原指针释放跳板
__attribute__((destructor)) void mod_auto_stop()
{
    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "进程退出，调用 persp_ptr_hook_stop() 清理");
    persp_ptr_hook_stop();
    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "persp_ptr_hook_stop 执行完毕，全部还原");
}

