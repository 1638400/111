LOCAL_PATH:= $(call my-dir)

include $(CLEAR_VARS)

LOCAL_CPPFLAGS += -fno-rtti -w -s -Wno-error=format-security -fvisibility=hidden -Werror -std=c++14

LOCAL_CPP_EXTENSION := .cpp .c

LOCAL_SRC_FILES = main.cpp

LOCAL_MODULE := main

LOCAL_LDLIBS += $(LOCAL_PATH)/driver.a

include $(BUILD_EXECUTABLE)
