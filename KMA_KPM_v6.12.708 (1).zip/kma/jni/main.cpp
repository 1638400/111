#include <iostream>
#include <thread>
#include <memory>
#include "driver.h"


int main(int argc, char *argv[])
{
    // 创建Driver对象
    // 方法1
    auto driver = std::make_unique<Driver>();
    
    // 方法2
    std::unique_ptr<Driver> driver2;
    driver2.reset(new Driver());

    // 方法3 注:扩展类用于读取[1, +∞]字节
    std::unique_ptr<Driver_EXT> driver3(new Driver_EXT());
    
    // 如果初始化失败 则不执行
    if (!driver->gid)
        return 0;

    if (!driver2->gid)
        return 0;

    if (!driver3->gid)
        return 0;
    
    
    // 程序运行在CPU0上
    driver->cpuset(0);

    // 程序随机运行在CPU0-4上，并且选择使用率最低的那颗CPU核心
    driver->cpuset(0, 4);

    // 又或者
    Driver::cpuset(4, 6);
    
    // 获取目标进程pid 进程存在则返回对应pid 否则返回0 一定不存在pid为0的进程 取值范围一般[1, 32768)
    pid_t pid = driver->get_pid("bin.mt.plus");
    pid_t pid2 = driver2->get_pid("com.android.settings");
    
    printf("pid = %d, pid2 = %d\n", pid, pid2);
    
    // 初始化pid，指定创建名为driver的对象作用于该pid对应的进程。
    if (0 < pid && pid < 32768)
        driver->initpid(pid);
    
    /*
	获取so模块地址
	7814006000-7814043000 r-xp 00000000 fe:0c 2891631                        /data/app/~~Ga0Qoijfa6Srj16BrdylTQ==/bin.mt.plus-2g1bTpkzPU3q-oLrAsFU-A==/lib/arm64/libmt1.so
	在一定程度上，应用进程每个版本的模块长度(大小)都是固定，即0x7814043000-0x7814006000=0x3D000
	get_module_base方法在内核层中获取模块地址，参数: 进程pid 模块名称 模块长度
	uint64_t so = driver->get_module_base(pid, "libmt1.so", 0x3D000);
	
	该方法有一个重载方法，当不传入模块长度时，默认取加载的第一行作为模块头
	uint64_t so = driver->get_module_base(pid, "libmt1.so");
	*/

    // 使用自身进程为例子
    pid = getpid();
    driver->initpid(pid);

    // 获取libc.so模块地址 具体可查看/proc/self/maps
    uintptr_t base = driver->get_module_base(pid, "libc.so");

    // 读取该地址上的值 安全稳定的内存驱动需要做到验证页面交换、新页状态、页缺失等等，当读取不到数据时需要考虑页面是否被交换(例如RAM->ZRAM)、或者新页未分配等等因素，当然不排除设备不支持该读取方法
    uint64_t val_1 = driver->read<uint64_t>(base);
    uint64_t val_2 = driver->read_nocache<uint64_t>(base);
    uint64_t val_3 = driver->read_safe<uint64_t>(base);

    printf("base = %p\nval_1 = 0x%lX\nval_2 = 0x%lX\nval_3 = 0x%lX\n", base, val_1, val_2, val_3);

    // 现在我们尝试读取不同类型的数据
    float demo_1 = 1314.520f;
    double demo_2 = 3.141'592'653'589'793;
    int demo_3 = 777;
    short demo_4 = 2026;
    char demo_5 = 'K';
    char demo_6[64] = "Hello KMA";
    float demo_7[16] =
        {
            -1.0f,
            -2.0f,
            -3.0f,
            0,
            100.0f,
            200.0f,
            300.0f,
            0,
            10.0f,
            20.0f,
            30.0f,
            123.0f,
            3.0f,
            1423.0f,
            555.0f,
            341.0f,
        };

    // 这里因为访问的是自身进程，所以使用&进行取地址，实际需要传入目标进程的地址，类型为uintptr_t
    uintptr_t demo_1_addr = (uintptr_t)&demo_1;
    uintptr_t demo_2_addr = (uintptr_t)&demo_2;
    uintptr_t demo_3_addr = (uintptr_t)&demo_3;
    uintptr_t demo_4_addr = (uintptr_t)&demo_4;
    uintptr_t demo_5_addr = (uintptr_t)&demo_5;
    uintptr_t demo_6_addr = (uintptr_t)&demo_6;
    uintptr_t demo_7_addr = (uintptr_t)&demo_7;
    
    float demo_1_val = driver->read<float>(demo_1_addr);
    double demo_2_val = driver->read<double>(demo_2_addr);
    int demo_3_val = driver->read<int>(demo_3_addr);
    short demo_4_val = driver->read_nocache<short>(demo_4_addr);
    char demo_5_val = driver->read_nocache<char>(demo_5_addr);

    char demo_6_val[64] = {};
    driver->read_nocache(demo_6_addr, demo_6_val, sizeof(demo_6_val));

    // 如果目标进程该数据常驻内存，可以使用read_safe方法，因为只需要初始化一次(创建DMA通道)，此时读取效率将达到高潮
    // 注：read_safe方法在初次读取一个未被读取的地址时会异常慢，耗时0.1-4ms不等，因此无论是测速或者用于其他，需先预热读取一遍，第二次才能正常工作。
    // float demo_7_val[16] = {};
    float *demo_7_val = (float *)driver->read_safe(demo_7_addr, 64);

    printf("%.3f, %.15f, %d, %d, %c, %s\n\n",
           demo_1_val,
           demo_2_val,
           demo_3_val,
           demo_4_val,
           demo_5_val,
           demo_6_val);

    for (int i = 0, j = 16; i < j; i++)
        printf("demo_7_val[%d] = %.5f\n", i, demo_7_val[i]);

    // 现在尝试写入数据 将demo_3的值修改为 777666
    driver->write<int>(demo_3_addr, 777666);
    demo_3_val = driver->read<int>(demo_3_addr);

    printf("\n修改后 demo_3_val = %d\n", demo_3_val);

    // 因为一个对象Driver只能作用于一个进程 or 线程，所以创建一个线程就需要创建一个对象，切记KMA不支持fork，且目前Driver对象暂时只能创建 nproc/2 个，一般移动设备nproc=8，所以最大支持4个Driver对象
    // 现在创建一个线程
    std::thread(
        [&] {
            printf("\n开始线程...\n");
            // 一个进程(线程)可以使用多个对象，但一个对象仅用于一个(进程)线程。
            
            // 创建Driver对象
            auto driver = std::make_unique<Driver>();
            
            // 如果初始化失败 则不执行
            if (!driver->gid)
            {
                printf("线程: 初始化失败 gid = 0\n");
                return;
            }
            // 绑定该线程在小核运行
            driver->cpuset(0, 2);

            pid_t pid = driver->get_pid("com.android.settings");

            // 初始化pid
            driver->initpid(pid);

            // 读取libc.so模块地址
            uintptr_t base = driver->get_module_base(pid, "libc.so");
            uint64_t val = driver->read<uint64_t>(base);
            uint64_t val2 = driver->read_safe<uint64_t>(base);

            printf("线程: base = %p, val = 0x%lX, val2 = 0x%lX\n", base, val, val2);
        })
        .join();

    //将驱动引用计数清零，释放本次在内核中创建的资源，并解锁驱动，以待下次使用，进程结束前任意一个对象调用该方法即可
    //如果对象都是智能指针封装，或者手动delete，则不需要调用，切勿在运行过程调用，否则会出现奇奇怪怪的问题，例如空指针异常
    //driver->destroy();
}
