#! /bin/bash
path=$(pwd)
if [[ -f $path/libs/arm64-v8a/main ]]
then
    main=$path/libs/arm64-v8a/main
    cd /data/user/0/bin.mt.plus/home
    cp $main .
    chmod a+x ./main
    ./main
fi